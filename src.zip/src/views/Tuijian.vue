<template>
  <div>
    分类
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
