<template>
  <div>我的</div>
</template>

<script>
export default {
  name: "Me",
  methods: {},
  mounted() {
    console.log("me");
  }

};
</script>

<style lang="scss" scoped></style>
