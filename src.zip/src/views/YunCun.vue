<template>
  <div>云村</div>
</template>

<script>
export default {
  mounted() {

  },
};
</script>

<style lang="scss" scoped></style>
